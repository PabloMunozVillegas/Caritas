import React, { useState } from 'react';
import InicioSesion from './Pages/IncioSesion';

function App() {
  return (
    <InicioSesion/>
  );
}

export default App;

